{
    'name': "Clinic",
    'application': "True",
    'data': [
        # 'security/ir.model.access.csv',
        'views/patient_registration.xml',
        'views/clinic_menu.xml',

    ]
}

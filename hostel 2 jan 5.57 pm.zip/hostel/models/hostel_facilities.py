from email.policy import default

from odoo import models, fields, api


class HostelFacilities(models.Model):
    _name = "hostel.facilities"
    _description = "Facilities"

    name = fields.Char(required=True)
    charge = fields.Monetary()
    currency_id = fields.Many2one("res.currency", default=lambda
        self: self.env.user.company_id.currency_id)
    _sql_constraints = [
        ('price_check', 'CHECK(charge > 0)', ' Invalid Charge'),
    ]

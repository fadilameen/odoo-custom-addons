# -*- coding: utf-8 -*-

from . import hostel_room
from . import hostel_student
from . import hostel_facility

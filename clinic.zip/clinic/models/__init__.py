from . import patient_registration
from . import op_ticket
from . import clinic_consultation

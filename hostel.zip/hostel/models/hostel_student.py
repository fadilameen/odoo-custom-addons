from odoo import models
from odoo import fields


class HostelStudent(models.Model):
    _name = "hostel.student"
    _description = "Hostel Student"

    name = fields.Many2one("res.partner", required=True, string="Student Name")
    student_id = fields.Char(string="Student ID")
    date_of_birth = fields.Date(required=True)
    room_no = fields.Many2one("hostel.room", )
    email = fields.Char()
    image = fields.Image()
    receive_mail = fields.Boolean()
    street = fields.Char(related="name.street")
    street2 = fields.Char(related="name.street2")
    city = fields.Char(related="name.city")
    state_id = fields.Many2one(related="name.state_id")
    zip = fields.Char(related="name.zip")
    country_id = fields.Many2one(related="name.country_id")

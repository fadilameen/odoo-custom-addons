{
    'name': 'hostel',
    'application': "True",
    'depends': ['mail', ],

    'data': [
        'security/ir.model.access.csv',
        'views/hostel_room_view.xml',
        'views/hostel_student_view.xml',
        'views/hostel_menu.xml',

    ]
}

# -*- coding: utf-8 -*-
from email.policy import default

from odoo import models, api
from odoo import fields
from odoo.exceptions import ValidationError


class HostelStudent(models.Model):
    """Defining structure of students"""

    _name = "hostel.student"
    _description = "Hostel Student"

    name = fields.Many2one("res.partner", required=True,
                           string="Student Name")
    student_id = fields.Integer(string="Student ID", related="name.id")
    date_of_birth = fields.Date(default=False)
    room_no = fields.Many2one("hostel.room", )
    email = fields.Char(related="name.email")
    image = fields.Image(string="Image")
    receive_mail = fields.Boolean(default=False)
    street = fields.Char(related="name.street")
    street2 = fields.Char(related="name.street2")
    city = fields.Char(related="name.city")
    state_id = fields.Many2one(related="name.state_id")
    zip = fields.Char(related="name.zip")
    country_id = fields.Many2one(related="name.country_id")

    @api.constrains('room_no')
    def _constrains_check_room(self):
        """restricting student allocation to room which is already full"""
        for record in self:
            if record.room_no.person_count > record.room_no.number_of_beds:
                raise ValidationError("Room is already full")

    _sql_constraints = [
        ('unique_tag', 'unique(name)', ' Student Already Exists'),
    ]
